<template>
  <h1>About</h1>
</template>

<style scoped>
h1 {
  color: red;
}
</style>